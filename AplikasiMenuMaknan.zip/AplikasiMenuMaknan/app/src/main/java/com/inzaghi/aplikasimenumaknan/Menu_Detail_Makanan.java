package com.inzaghi.aplikasimenumaknan;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import aplikasi.mobile.listviewimage.R;

public class Menu_Detail_Makanan extends Activity {

    String HargaItem, NamaItem, Deskripsi;
    int Gambar;

    TextView tvHarga, tvNamaItem, tvDeskripsi;
    ImageView ImgGembar;

    @Override
    public void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_detail_makanan);

        tvHarga		    = (TextView)findViewById(R.id.textView2);
        tvNamaItem		= (TextView)findViewById(R.id.textView1);
        tvDeskripsi		= (TextView)findViewById(R.id.textView3);
        ImgGembar		= (ImageView)findViewById(R.id.imageView1);

        Intent i 		= getIntent();
        HargaItem		= i.getStringExtra("HargaItem");
        NamaItem		= i.getStringExtra("NamaItem");
        Deskripsi	 	= i.getStringExtra("Deskripsi");
        Gambar			= i.getIntExtra("Gambar", Gambar);

        tvHarga.setText(HargaItem);
        tvNamaItem.setText(NamaItem);
        tvDeskripsi.setText(Deskripsi);
        ImgGembar.setImageResource(Gambar);

    }

}