package com.inzaghi.aplikasimenumaknan;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

import aplikasi.mobile.listviewimage.R;

public class Menu_Daftar_Makanan extends AppCompatActivity {

    ListView lvItem;
    ListViewAdapterCall adapter;
    ArrayList<ListViewAdapterMenu> arraylist = new ArrayList<ListViewAdapterMenu>();

    int[] Gambar;
    String[] NamaItem;
    String[] HargaItem;
    String[] Deskripsi;

    @Override
    public void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_daftar_makanan);

        lvItem = (ListView) findViewById(R.id.listView1);


        Gambar = new int[]{
                R.mipmap.a_tumisbungapepaya,
                R.mipmap.b_lawarikan,
                R.mipmap.c_jagungbose,
                R.mipmap.d_seisapi,
                R.mipmap.e_jagungtiti};

        NamaItem = new String[]{
                "Sayur Tumis Pepaya",
                "Lawar Ikan",
                "Jagung Bose",
                "Sei Sapi",
                "Jagung Titi"};

        HargaItem = new String[]{
                "25.000",
                "50.000",
                "100.000",
                "125.000",
                "50.000"};

        Deskripsi = new String[]{
                "Sayur tumis pepaya merupakan makanan khas daerah NTT, dimana sayur ini tidak memiliki " +
                        "rasa pahit namun sangat nikmat dan manis bila disantap dengan ikan panggang " +
                        "atau menu makanan lainnya yang berkuah",

                "Lawar Ikan merupakan makanan semi lombok yang diberikan cuka, bawang merah, garam, dan ikan alus untuk " +
                        "dimakan bersama lauk pauk lainnya",

                "Jagung bose adalah makanan khas daerah Timor",

                "Sei sapi enak dan bergizi tinggi, dikelola dengan cara diasapi",

                "Jagung titi enaknya!"};


        for (int i = 0; i < NamaItem.length; i++) {
            ListViewAdapterMenu wp = new ListViewAdapterMenu(NamaItem[i], HargaItem[i], Deskripsi[i], Gambar[i]);
            arraylist.add(wp);
        }

        adapter = new ListViewAdapterCall(this, arraylist);
        lvItem.setAdapter(adapter);


    }
}
