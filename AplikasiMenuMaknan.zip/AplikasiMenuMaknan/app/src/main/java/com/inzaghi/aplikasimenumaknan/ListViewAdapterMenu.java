package com.inzaghi.aplikasimenumaknan;

class ListViewAdapterMenu {
    private String NamaItem, HargaItem, Deskripsi;
    private int Gambar;

    public ListViewAdapterMenu(String NamaItem, String HargaItem, String Deskripsi, int Gambar) {
        this.NamaItem = NamaItem;
        this.HargaItem = HargaItem;
        this.Deskripsi = Deskripsi;
        this.Gambar = Gambar;

    }

    public String getNamaItem() {

        return this.NamaItem;
    }

    public String getHargaItem() {

        return this.HargaItem;
    }

    public String getDeskripsi() {

        return this.Deskripsi;
    }

    public int getGambar() {

        return this.Gambar;
    }
}